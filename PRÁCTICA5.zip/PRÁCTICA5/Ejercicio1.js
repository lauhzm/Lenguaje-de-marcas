function cambioColor() {
    document.getElementById("Título").style.color = 'red';
}

function cambioEnfasis() {
    document.getElementById("Párrafo").style.fontWeight = 'bold';
}