function cambioDiv1() {
    document.getElementById("bloque1").style.display = "none";
    document.getElementById("bloque2").style.display = "block";
}

function cambioDiv2() {
    document.getElementById("bloque2").style.display = "none";
    document.getElementById("bloque1").style.display = "block";
}