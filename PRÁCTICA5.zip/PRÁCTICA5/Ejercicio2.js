function cambioTamaño() {
    document.getElementById("imagen").style.width = "80px";
    document.getElementById("imagen").style.height = "100px";
}

function cambioFoto() {
    document.getElementById("imagen").src = 'Amigos.png';
}